# Руководство по миграции

## Что изменилось

### ✅ Удалено
- `src/legacy/` — весь устаревший код
- `src/bot/index.js` — старая реализация бота
- `src/web/static.js` — дублирующий код
- `public/111.json` — неиспользуемый файл
- `README_COUNTERS_PATCH.txt` — устаревшая документация

### ✨ Создано
- `src/routes/` — модульные HTTP маршруты
- `src/bot/telegram.js` — новая реализация бота
- `src/lib/csvParser.js` — парсинг CSV
- `src/lib/blocklist.js` — работа с блок-листами
- `src/lib/reasonTexts.js` — тексты ошибок
- `src/scheduler/followup.js` — планировщик
- `PROJECT_STRUCTURE.md` — описание структуры

### 🔧 Исправлено
- **Критично**: Удален хардкод API ключа Mailboxlayer
- Исправлены ошибки экспорта в модулях
- Убраны странные UUID из кода
- Добавлена переменная `MAILBOXLAYER_API_KEY` в .env

### 📦 Реорганизовано
- Монолитный `server.js` (912 строк) → модульная структура
- Все функции теперь в соответствующих модулях
- Нет дублирования кода
- Понятная структура зависимостей

## Миграция

### 1. Обновите .env файл

Добавьте новую переменную:
```bash
MAILBOXLAYER_API_KEY=your_key_here
```

### 2. Проверьте зависимости

```bash
npm install
```

Все зависимости остались прежними, ничего нового устанавливать не нужно.

### 3. Проверьте конфигурацию

Файл `src/config/emailValidation.json` теперь используется для настройки валидации.
Если вы его редактировали — проверьте, что настройки корректны.

### 4. Запустите сервер

```bash
npm start
```

Сервер должен запуститься без ошибок и вывести:
```
✅ Server listening on port 3000
📁 Data directory: /path/to/data
🌐 Base URL: https://your-domain.com
📧 SendGrid: configured
🤖 Telegram bot: enabled
```

### 5. Проверьте функциональность

#### API
```bash
curl http://localhost:3000/health
# Должен вернуть: {"ok":true}
```

#### Отправка письма
```bash
curl -X POST http://localhost:3000/api/send \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","text":"Test message"}'
```

#### Метрики
```bash
curl http://localhost:3000/api/series?days=7
```

#### Веб-дашборд
Откройте в браузере: `http://localhost:3000/`

#### Telegram бот
Отправьте `/start` вашему боту

## Обратная совместимость

### API
✅ Все эндпоинты остались прежними:
- `POST /api/send`
- `POST /sendgrid/events`
- `POST /sendgrid/inbound`
- `GET /api/series`
- `GET /health`

### Данные
✅ Формат всех файлов данных не изменился:
- `db.json`
- `counters.json`
- `tokens`
- `config.json`

### Конфигурация
✅ Все ENV переменные работают как раньше.
➕ Добавлена новая: `MAILBOXLAYER_API_KEY`

## Что делать при проблемах

### Ошибка: "Cannot find module"
```bash
npm install
```

### Ошибка: "MAILBOXLAYER_API_KEY not set"
Это не критично. Валидация email будет работать без Mailboxlayer (только DNS).
Если хотите использовать Mailboxlayer — добавьте ключ в .env.

### Ошибка: "SENDGRID_API_KEY not set"
Добавьте ключ SendGrid в .env:
```bash
SENDGRID_API_KEY=SG.xxxxx
```

### Telegram бот не отвечает
Проверьте:
1. `TELEGRAM_BOT_TOKEN` в .env
2. Бот запущен (в логах должно быть "Telegram bot: enabled")
3. Нет ошибок в логах

### Веб-дашборд не открывается
Проверьте:
1. Сервер запущен
2. Порт не занят другим процессом
3. Файлы в `public/` на месте

## Откат на старую версию

Если что-то пошло не так, вы можете откатиться на предыдущий коммит:

```bash
git log --oneline  # найдите хеш коммита до рефакторинга
git checkout <hash>
npm install
npm start
```

## Поддержка

Если возникли проблемы:
1. Проверьте логи сервера
2. Проверьте `DATA_DIR/activity.log`
3. Проверьте `DATA_DIR/logs/{id}.log` для конкретного письма
4. Откройте issue в репозитории
