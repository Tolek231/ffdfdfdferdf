# Wandlead Sender

Модульная система email-рассылок с интеграцией SendGrid, Telegram-ботом и веб-дашбордом.

## Возможности

- ✉️ Отправка писем через SendGrid API
- 🤖 Telegram-бот для управления рассылками
- 📊 Веб-дашборд с метриками и аналитикой
- 🔍 Валидация email (DNS + Mailboxlayer)
- 📈 Отслеживание открытий и ответов
- 🎯 Мульти-тенантность (токены кабинетов)
- 🚫 Блок-листы и фильтры
- 📥 Загрузка CSV для массовых рассылок

## Быстрый старт

```bash
# Установка зависимостей
npm install

# Настройка окружения
cp .env.example .env
# Отредактируйте .env и укажите ваши ключи

# Запуск
npm start
```

Сервер запустится на порту из `PORT` (по умолчанию 3000).

## Документация

### Начало работы
- [QUICKSTART.md](QUICKSTART.md) — быстрый старт за 3 минуты ⚡
- [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md) — руководство по миграции
- [CHECKLIST.md](CHECKLIST.md) — чеклист проверки

### Архитектура
- [ARCHITECTURE.md](ARCHITECTURE.md) — архитектура и структура проекта
- [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) — детальная структура файлов
- [TREE.txt](TREE.txt) — визуальное дерево проекта

### Разработка
- [CONTRIBUTING.md](CONTRIBUTING.md) — правила разработки
- [docs/API.md](docs/API.md) — описание HTTP API
- [README_TOKENS.md](README_TOKENS.md) — работа с токенами

### Эксплуатация
- [OPERATIONS.md](OPERATIONS.md) — деплой и эксплуатация

### История
- [CHANGELOG.md](CHANGELOG.md) — список изменений
- [REFACTORING_SUMMARY.md](REFACTORING_SUMMARY.md) — резюме рефакторинга

## Безопасность

⚠️ **Важно**: Не храните секреты в репозитории!
- Реальные ENV переменные — в Amvera или Docker
- Локально используйте `.env` (добавлен в .gitignore)

## Docker
Сборка и запуск локально:
```bash
docker build -t sender-app .
docker run --rm -p 3000:3000       -e SENDGRID_API_KEY=...       -e FROM_EMAIL=...       -e TELEGRAM_BOT_TOKEN=...       -e DATA_DIR=/data       -v $PWD/.local-data:/data       sender-app
```

Проверка:
```bash
curl http://localhost:3000/health
```

### Проблемы с портом 80 (EACCES)
Если хостинг принудительно выставляет `PORT=80/443`, контейнер может падать с `EACCES`.
В Dockerfile добавлен `setcap` дл1я `/usr/local/bin/node`, поэтому запуск под пользователем `node`
сможет слушать 80/443 без root. Альтернатива — задать `PORT=3000` и проксировать трафик на него.

### Amvera и PORT=80
Некоторые окружения запускают контейнер с флагом `no-new-privileges`, из-за чего capability `CAP_NET_BIND_SERVICE`
(даже если выставлена через `setcap`) игнорируется, и процесс не может слушать 80/443 как non-root. Для таких случаев
Dockerfile настроен на запуск от root, чтобы исключить `EACCES` на 80. Если ваша платформа позволит — можно вернуть
запуск под `node` и `setcap` (см. предыдущий вариант Dockerfile).

### Упрощённый Dockerfile для Amvera
Из-за ошибки `/bin/sh: syntax error: unexpected "then" (expecting "fi")` у билдера
упрощена логика установки зависимостей: теперь используется единственная строка
`RUN [ -f package-lock.json ] && npm ci --omit=dev || npm i --omit=dev` без `elif`.
Также `EXPOSE 80` добавлен для совместимости с PaaS.

## Docker запуск
```bash
docker build -t sender-app .
docker run --rm -p 80:80       -e PORT=80       -e DATA_DIR=/data       -e SENDGRID_API_KEY=...       -e FROM_EMAIL=...       -e TELEGRAM_BOT_TOKEN=...       -e TELEGRAM_ADMIN_IDS=123,456       -e BASE_URL=https://your-domain       -v $PWD/.local-data:/data       sender-app
curl -i http://localhost/health
```
